from principal.models import Receta, Comentario
from django.contrib import admin

admin.site.register(Receta)
admin.site.register(Comentario)
